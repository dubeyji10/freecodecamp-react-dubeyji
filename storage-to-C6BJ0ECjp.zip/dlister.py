#!/usr/bin/env python3
"""
Torrent media-only downloader (config-driven).

Edit the CONFIG block below, then run:  python torrent_dl.py
"""

import os
import time
import libtorrent as lt

# ============================== CONFIG ========================================

TORRENT_FILE = r"E:\ebo-automate-2\tester\sns04.torrent"
DOWNLOAD_DIR = "downs"

# Set to True to only scan and write a report — no downloading.
DRY_RUN = True

# Where the dry-run report is written.
REPORT_FILE = "reps.txt"

# Which files to download:
#   None            -> auto-select all media files (by extension)
#   [2, 5, 7]       -> download ONLY these file indexes (from the report)
SELECTED_INDEXES = None

# Extensions we consider "media"
MEDIA_EXTENSIONS = {
    # Video
    ".mp4", ".mkv", ".avi", ".mov", ".wmv", ".flv", ".webm",
    ".m4v", ".mpg", ".mpeg", ".ts", ".m2ts", ".vob", ".3gp",
    # Audio
    ".mp3", ".flac", ".aac", ".ogg", ".wav", ".m4a", ".wma",
    ".opus", ".aiff", ".alac",
    # Subtitles
    ".srt", ".sub", ".ass", ".vtt",
}

LISTEN_PORT = 6881
# ==============================================================================


def is_media(filename: str) -> bool:
    return os.path.splitext(filename.lower())[1] in MEDIA_EXTENSIONS


def human_size(num_bytes: int) -> str:
    for unit in ("B", "KiB", "MiB", "GiB", "TiB"):
        if num_bytes < 1024:
            return f"{num_bytes:.2f} {unit}"
        num_bytes /= 1024
    return f"{num_bytes:.2f} PiB"


def load_torrent(torrent_path: str):
    if not os.path.isfile(torrent_path):
        raise SystemExit(f"Error: torrent file not found: {torrent_path}")

    session = lt.session()
    session.listen_on(LISTEN_PORT, LISTEN_PORT + 10)
    session.add_dht_router("router.bittorrent.com", 6881)
    session.add_dht_router("router.utorrent.com", 6881)
    session.add_dht_router("dht.transmissionbt.com", 6881)
    session.start_dht()

    info = lt.torrent_info(torrent_path)
    handle = session.add_torrent({
        "ti": info,
        "save_path": os.path.abspath(DOWNLOAD_DIR),
    })
    return session, handle, info


def list_files(info) -> list:
    storage = info.files()
    return [
        {
            "index": i,
            "path":  storage.file_path(i),
            "size":  storage.file_size(i),
            "media": is_media(storage.file_path(i)),
        }
        for i in range(storage.num_files())
    ]


def build_table(info, files) -> str:
    """Return a formatted listing of every file in the torrent."""
    lines = []
    lines.append(f"Torrent : {info.name()}")
    lines.append(f"Total   : {human_size(info.total_size())} "
                 f"({info.num_pieces()} pieces x {human_size(info.piece_length())})")
    lines.append("")
    lines.append(f"{'#':>4}  {'Size':>10}  {'Media':>5}  Path")
    lines.append("-" * 78)
    for f in files:
        flag = "yes" if f["media"] else ""
        lines.append(f"{f['index']:>4}  {human_size(f['size']):>10}  {flag:>5}  {f['path']}")
    lines.append("-" * 78)

    media_idx = [f["index"] for f in files if f["media"]]
    lines.append(f"{len(media_idx)} media file(s) out of {len(files)} total.")
    lines.append("")
    lines.append("Paste the line below into SELECTED_INDEXES in the script "
                 "to download exactly these:")
    lines.append("")
    lines.append(f"SELECTED_INDEXES = {media_idx}")
    return "\n".join(lines)


def write_report(info, files, report_path=REPORT_FILE):
    text = build_table(info, files)
    with open(report_path, "w", encoding="utf-8") as fh:
        fh.write(text + "\n")
    print(f"📝 Report written to: {os.path.abspath(report_path)}")


def choose_indexes(files) -> list:
    """Return the list of file indexes to download."""
    if SELECTED_INDEXES is not None:
        # Validate against the torrent
        valid = {f["index"] for f in files}
        bad = [i for i in SELECTED_INDEXES if i not in valid]
        if bad:
            raise SystemExit(f"Error: these indexes are not in the torrent: {bad}")
        return list(SELECTED_INDEXES)
    return [f["index"] for f in files if f["media"]]


def apply_selection(handle, files, selected_indexes: list) -> None:
    handle.set_flags(lt.torrent_flags.auto_managed, False)
    handle.pause()

    priorities = [0] * len(files)
    for idx in selected_indexes:
        priorities[idx] = 4

    handle.prioritize_files(priorities)
    handle.resume()


def print_progress(handle):
    state_str = [
        "queued", "checking", "downloading metadata", "downloading",
        "finished", "seeding", "allocating", "checking resume data",
    ]
    while True:
        s = handle.status()
        bar_len = 30
        filled = int(bar_len * s.progress)
        bar = "█" * filled + "░" * (bar_len - filled)
        state = state_str[s.state] if s.state < len(state_str) else "unknown"

        print(
            f"\r[{bar}] {s.progress*100:5.1f}%  "
            f"↓ {s.download_rate/1024:7.1f} KiB/s  "
            f"↑ {s.upload_rate/1024:6.1f} KiB/s  "
            f"peers: {s.num_peers:3d}  state: {state}",
            end="", flush=True,
        )

        if s.is_seeding or s.progress >= 1.0:
            print("\n✅ Download complete.")
            break
        time.sleep(1)


def main():
    os.makedirs(DOWNLOAD_DIR, exist_ok=True)

    print(f"📂 Loading torrent: {TORRENT_FILE}")
    session, handle, info = load_torrent(TORRENT_FILE)
    files = list_files(info)

    print(build_table(info, files))
    print()

    if DRY_RUN:
        write_report(info, files)
        print("(dry-run — no download performed)")
        return

    selected = choose_indexes(files)

    if not selected:
        print("⚠️  No files selected — nothing to download.")
        return

    print(f"⬇️  Downloading {len(selected)} file(s) "
          f"(indexes: {selected}) to '{DOWNLOAD_DIR}/'\n")

    apply_selection(handle, files, selected)

    try:
        print_progress(handle)
    except KeyboardInterrupt:
        print("\n⏹️  Interrupted by user. Pausing torrent...")
        handle.pause()

    print(f"\nFiles saved under: {os.path.abspath(DOWNLOAD_DIR)}")


if __name__ == "__main__":
    main()